# PickupMoney
A Spigot plugin make money drop out for picking up <br>
Plugin on Spigot: https://www.spigotmc.org/resources/pickupmoney.11334/

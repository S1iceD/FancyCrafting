package me.gadse.fancycrafting.gui;

import me.gadse.fancycrafting.FancyCrafting;
import me.gadse.fancycrafting.util.DataRecipe;
import me.gadse.fancycrafting.util.Messages;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class RecipePreviewGUI implements IGUI {

    private final FancyCrafting plugin;
    private final Inventory inventory;
    private final List<Integer> craftingSlots = new ArrayList<>();
    private final ItemStack returnToListItem;
    private final int backSlot, resultSlot, returnToListSlot;
    private final List<String> backCommands;

    public RecipePreviewGUI(FancyCrafting plugin) {
        this.plugin = plugin;
        ConfigurationSection previewConfig = plugin.getConfig().getConfigurationSection("recipe_preview");
        if (previewConfig == null)
            throw new IllegalArgumentException("There is no recipe_preview in the config. Consider deleting it.");

        // Create the inventory
        inventory = plugin.getServer().createInventory(this,
                previewConfig.getInt("size", 54),
                Messages.color(previewConfig.getString("title"))
        );

        // Fill the inventory with the fill item
        ItemStack fill = plugin.getItemUtil().getItemStackFromConfig("fill");
        for (int i = 0; i < inventory.getSize(); i++)
            inventory.setItem(i, fill);

        // Cache items
        returnToListItem = plugin.getItemUtil().getItemStackFromConfig("return-to-list");
        ItemStack backItem = plugin.getItemUtil().getItemStackFromConfig("back");

        backCommands = plugin.getConfig().getStringList("items.back.commands");

        // Cache slots
        craftingSlots.addAll(previewConfig.getIntegerList("crafting-slots"));
        returnToListSlot = previewConfig.getInt("return-to-list-slot");
        resultSlot = previewConfig.getInt("result-slot");
        backSlot = previewConfig.getInt("back-slot");

        // Set items
        craftingSlots.forEach(integer -> inventory.setItem(integer, null));
        inventory.setItem(resultSlot, null);
        inventory.setItem(backSlot, backItem);
    }

    @Override
    public void onClick(InventoryClickEvent event) {
        if (event.getClickedInventory() == null)
            return;

        if (event.getClickedInventory().equals(event.getView().getBottomInventory())) {
            if (event.isShiftClick() || event.getAction() == InventoryAction.COLLECT_TO_CURSOR)
                event.setCancelled(true);
            return;
        }

        event.setCancelled(true);

        Player player = (Player) event.getWhoClicked();
        if (event.getRawSlot() == backSlot) {
            player.closeInventory();
            backCommands.forEach(command -> {
                command = command.replaceAll("%player%", event.getWhoClicked().getName());
                if (command.startsWith("[console]"))
                    plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), command);
                else
                    player.performCommand(command);
            });
        }

        if (event.getRawSlot() == returnToListSlot && player.hasPermission("fancycrafting.recipes.edit"))
            new RecipeListGUI(plugin, player);
    }

    @Override
    public void onDrag(InventoryDragEvent event) {
        event.setCancelled(true);
    }

    @Override
    public void onClose(InventoryCloseEvent event) {
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public Inventory getInventory(Player player, DataRecipe recipe) {
        Inventory inventoryCopy = plugin.getServer().createInventory(this, inventory.getSize(), inventory.getTitle());
        for (int i = 0; i < inventory.getSize(); i++)
            inventoryCopy.setItem(i, inventory.getItem(i));

        recipe.getIngredients().forEach((character, itemStack) ->
                inventoryCopy.setItem(craftingSlots.get(Integer.parseInt(String.valueOf(character))), itemStack));

        if (player.hasPermission("fancycrafting.recipes.edit"))
            inventoryCopy.setItem(returnToListSlot, returnToListItem);

        inventoryCopy.setItem(resultSlot, recipe.getOutput());

        return inventoryCopy;
    }
}

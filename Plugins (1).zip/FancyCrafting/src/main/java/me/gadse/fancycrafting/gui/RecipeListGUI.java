package me.gadse.fancycrafting.gui;

import me.gadse.fancycrafting.FancyCrafting;
import me.gadse.fancycrafting.util.Messages;
import me.gadse.fancycrafting.util.DataRecipe;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class RecipeListGUI implements IGUI {

    private final FancyCrafting plugin;
    private final Inventory inventory;
    private final ItemStack previousPageItem;
    private final ItemStack nextPageItem;
    private final int previousPageSlot;
    private final int nextPageSlot;
    private final String previewLore, editLore;

    private final Map<Integer, Consumer<InventoryClickEvent>> actionMap = new HashMap<>();

    public RecipeListGUI(FancyCrafting plugin, Player player) {
        this.plugin = plugin;

        ConfigurationSection listConfig = plugin.getConfig().getConfigurationSection("recipe_list");
        if (listConfig == null)
            throw new IllegalStateException("There is no recipe_list in the config. Consider deleting it.");

        // Create inventory
        inventory = plugin.getServer().createInventory(this,
                listConfig.getInt("size"),
                Messages.color(listConfig.getString("title"))
        );

        // Cache items
        previousPageItem = plugin.getItemUtil().getItemStackFromConfig("previous-page");
        nextPageItem = plugin.getItemUtil().getItemStackFromConfig("next-page");
        ItemStack backItem = plugin.getItemUtil().getItemStackFromConfig("back");
        ItemStack addRecipeItem = plugin.getItemUtil().getItemStackFromConfig("add-recipe");
        ItemStack workbenchItem = plugin.getItemUtil().getItemStackFromConfig("workbench");

        // Cache slots
        previousPageSlot = listConfig.getInt("previous-page-slot");
        nextPageSlot = listConfig.getInt("next-page-slot");
        int backSlot = listConfig.getInt("back-slot");
        int addRecipeSlot = listConfig.getInt("add-recipe-slot");
        int workbenchSlot = listConfig.getInt("workbench-slot");

        previewLore = Messages.color(listConfig.getString("preview-lore"));
        editLore = Messages.color(listConfig.getString("edit-lore"));

        // Set items
        inventory.setItem(backSlot, backItem);
        inventory.setItem(workbenchSlot, workbenchItem);

        boolean hasEditPerms = player.hasPermission("fancycrafting.recipes.edit");
        if (hasEditPerms)
            inventory.setItem(addRecipeSlot, addRecipeItem);

        // Set actions
        actionMap.put(addRecipeSlot, event -> {
            if (!hasEditPerms)
                return;
            player.openInventory(plugin.getRecipeEditGUI().getInventory());
        });

        actionMap.put(workbenchSlot, event -> plugin.getWorkbenchGUI().openInventoryForPlayer(player));

        List<String> commands = plugin.getConfig().getStringList("items.back.commands");
        actionMap.put(backSlot, event -> {
            event.getWhoClicked().closeInventory();
            commands.forEach(command -> {
                command = command.replaceAll("%player%", event.getWhoClicked().getName());
                if (command.startsWith("[console]"))
                    plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), command);
                else
                    player.performCommand(command);
            });
        });

        goToPage(0, hasEditPerms);
        player.openInventory(inventory);
    }

    private void goToPage(int page, boolean hasEditPerms) {
        int recipeSize = plugin.getFileStorage().getRecipes().size();
        int listSize = inventory.getSize() - 9;
        if (recipeSize > listSize) {
            if (page > 0) {
                inventory.setItem(previousPageSlot, previousPageItem);
                int previousPage = page - 1;
                actionMap.put(previousPageSlot, event -> goToPage(previousPage, hasEditPerms));
            } else {
                inventory.setItem(previousPageSlot, null);
                actionMap.put(previousPageSlot, null);
            }

            if (recipeSize > listSize * (page + 1)) {
                inventory.setItem(nextPageSlot, nextPageItem);
                int nextPage = page + 1;
                actionMap.put(nextPageSlot, event -> goToPage(nextPage, hasEditPerms));
            } else {
                inventory.setItem(nextPageSlot, null);
                actionMap.put(nextPageSlot, null);
            }
        } else
            page = 0;

        int recipeOffset = listSize * page;
        for (int i = 0; i < listSize; i++) {
            actionMap.put(i, null);
            inventory.setItem(i, null);
            if (i + recipeOffset >= recipeSize)
                continue;

            DataRecipe recipe = plugin.getFileStorage().getRecipes().get(i + recipeOffset);

            ItemStack itemStack = recipe.getOutput().clone();
            ItemMeta itemMeta = itemStack.getItemMeta();
            List<String> lore = itemMeta.hasLore() ? itemMeta.getLore() : new ArrayList<>();
            lore.add(previewLore);
            if (hasEditPerms)
                lore.add(editLore);
            itemMeta.setLore(lore);
            itemStack.setItemMeta(itemMeta);

            inventory.setItem(i, itemStack);
            actionMap.put(i, event -> {
                Player player = (Player) event.getWhoClicked();
                if (hasEditPerms && event.isRightClick())
                    player.openInventory(plugin.getRecipeEditGUI().getInventory(player, recipe));
                else
                    player.openInventory(plugin.getRecipePreviewGUI().getInventory(player, recipe));
            });
        }
    }

    @Override
    public void onClick(InventoryClickEvent event) {
        if (event.getClickedInventory() == null)
            return;

        if (event.getClickedInventory().equals(event.getView().getBottomInventory())) {
            if (event.isShiftClick() || event.getAction() == InventoryAction.COLLECT_TO_CURSOR)
                event.setCancelled(true);
            return;
        }

        event.setCancelled(true);

        Consumer<InventoryClickEvent> action = actionMap.get(event.getRawSlot());
        if (action == null)
            return;

        action.accept(event);
    }

    @Override
    public void onDrag(InventoryDragEvent event) {
        event.setCancelled(true);
    }

    @Override
    public void onClose(InventoryCloseEvent event) {
        // DO NOTHING
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}

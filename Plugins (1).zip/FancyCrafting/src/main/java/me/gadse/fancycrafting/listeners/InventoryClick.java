package me.gadse.fancycrafting.listeners;

import me.gadse.fancycrafting.gui.IGUI;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class InventoryClick implements Listener {
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof IGUI))
            return;

        IGUI igui = (IGUI) event.getInventory().getHolder();
        igui.onClick(event);
    }
}

package me.gadse.fancycrafting.util;

import me.gadse.fancycrafting.FancyCrafting;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.MemorySection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileStorage {

    private final File file;
    private final FileConfiguration fileConfig;

    private final List<DataRecipe> recipes = new ArrayList<>();

    public FileStorage(FancyCrafting plugin) {
        file = new File(plugin.getDataFolder(), "data.yml");
        if (!file.exists()) {
            plugin.saveResource("data.yml", false);
        }

        fileConfig = new YamlConfiguration();
        try {
            fileConfig.load(file);
            fileConfig.getKeys(false).forEach(key -> {
                ItemStack result = fileConfig.getItemStack(key + ".result");
                DataRecipe recipe = new DataRecipe(result,
                        fileConfig.getString(key + ".name", ""),
                        fileConfig.getBoolean(key + ".use-permission", false));

                Object ingredientsObject = fileConfig.get(key + ".ingredients");
                if (!(ingredientsObject instanceof MemorySection))
                    return;

                MemorySection ingredientsSection = (MemorySection) ingredientsObject;
                for (int i = 0; i < 9; i++)
                    recipe.setIngredient(i, ingredientsSection.getItemStack(String.valueOf(i)));

                recipes.add(recipe);
            });
        } catch (IOException | InvalidConfigurationException e) {
            e.printStackTrace();
        }
    }

    public void save() {
        fileConfig.getKeys(false).forEach(key -> fileConfig.set(key, null));
        for (int i = 0; i < recipes.size(); i++) {
            DataRecipe recipe = recipes.get(i);
            fileConfig.set(i + ".name", recipe.getName());
            fileConfig.set(i + ".use-permission", recipe.isUsePermission());
            fileConfig.set(i + ".result", recipe.getOutput());
            fileConfig.set(i + ".ingredients", recipe.getIngredients());
        }

        try {
            fileConfig.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addRecipe(DataRecipe recipe) {
        recipes.add(recipe);
        save();
    }

    public List<DataRecipe> getRecipes() {
        return recipes;
    }

    public void removeRecipe(DataRecipe recipe) {
        recipes.remove(recipe);
        save();
    }

    public DataRecipe getRecipeByName(String name) {
        return recipes.stream().filter(recipe -> recipe.getName().equals(name)).findFirst().orElse(null);
    }
}

package me.gadse.fancycrafting.util;

import java.util.HashMap;
import java.util.Map;

import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.inventory.ItemStack;

public class DataRecipe {

    private final ItemStack output;
    private final String name;
    private final boolean usePermission;
    private final Map<Integer, ItemStack> ingredients = new HashMap<>();

    public DataRecipe(ItemStack output, String name, boolean usePermission) {
        this.output = output.clone();
        this.name = name == null ? "" : name;
        this.usePermission = usePermission;
    }

    public void setIngredient(int slot, ItemStack item) {
        if (item == null)
            item = new ItemStack(Material.AIR);
        ingredients.put(slot, item);
    }

    public ItemStack getOutput() {
        return output;
    }

    public Map<Integer, ItemStack> getIngredients() {
        return ingredients;
    }

    public boolean fits(HumanEntity player, ItemStack[] itemStacks) {
        if (usePermission && !name.isEmpty() && !player.hasPermission("fancycrafting.recipe." + name))
            return false;

        for (int i = 0; i < itemStacks.length; i++) {
            ItemStack input = itemStacks[i];
            ItemStack ingredient = ingredients.get(i);
            if (input == null || input.getType() == Material.AIR) {
                if (ingredient == null || ingredient.getType() == Material.AIR)
                    continue;
                return false;
            }

            if (!input.isSimilar(ingredient) || input.getAmount() < ingredient.getAmount())
                return false;
        }
        return true;
    }

    public String getName() {
        return name;
    }

    public boolean isUsePermission() {
        return usePermission;
    }
}


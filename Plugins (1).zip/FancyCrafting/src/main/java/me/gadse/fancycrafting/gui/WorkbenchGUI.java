package me.gadse.fancycrafting.gui;

import me.gadse.fancycrafting.FancyCrafting;
import me.gadse.fancycrafting.util.Messages;
import net.minecraft.server.v1_8_R3.*;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_8_R3.event.CraftEventFactory;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftInventoryCrafting;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftInventoryView;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;

import java.util.*;
import java.util.function.Consumer;

public class WorkbenchGUI implements IGUI {

    private final FancyCrafting plugin;
    private final Inventory inventory;
    private final Map<Integer, Consumer<InventoryClickEvent>> actionMap = new HashMap<>();
    private final List<Integer> craftingSlots = new ArrayList<>();
    private final Set<Integer> validationSlots = new HashSet<>();
    private final int resultSlot;
    private final ItemStack validCraftItem, invalidCraftItem, emptyResultItem;

    private final Map<UUID, Inventory> inventoryMap = new HashMap<>();

    public WorkbenchGUI(FancyCrafting plugin) {
        this.plugin = plugin;
        ConfigurationSection workbenchConfig = plugin.getConfig().getConfigurationSection("workbench");
        if (workbenchConfig == null)
            throw new IllegalArgumentException("There is no workbench in the config. Consider deleting it.");

        // Create the inventory
        inventory = plugin.getServer().createInventory(this,
                workbenchConfig.getInt("size", 54),
                Messages.color(workbenchConfig.getString("title"))
        );

        // Fill the inventory with the fill item
        ItemStack fill = plugin.getItemUtil().getItemStackFromConfig("fill");
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, fill);
            actionMap.put(i, event -> event.setCancelled(true));
        }

        // Set the validation items
        validCraftItem = plugin.getItemUtil().getItemStackFromConfig("valid-craft");
        invalidCraftItem = plugin.getItemUtil().getItemStackFromConfig("invalid-craft");
        validationSlots.addAll(workbenchConfig.getIntegerList("craft-state-slots"));
        validationSlots.forEach(integer -> inventory.setItem(integer, invalidCraftItem));

        // Set the back item
        ItemStack backItem = plugin.getItemUtil().getItemStackFromConfig("back");
        List<String> commands = plugin.getConfig().getStringList("items.back.commands");
        int backSlot = workbenchConfig.getInt("back-slot");
        inventory.setItem(backSlot, backItem);
        actionMap.put(backSlot, event -> {
            event.setCancelled(true);
            event.getWhoClicked().closeInventory();
            commands.forEach(command -> {
                command = command.replaceAll("%player%", event.getWhoClicked().getName());
                if (command.startsWith("[console]"))
                    plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), command);
                else {
                    Player player = (Player) event.getWhoClicked();
                    player.performCommand(command);
                }
            });
        });

        // Set the crafting slots
        craftingSlots.addAll(workbenchConfig.getIntegerList("crafting-slots"));
        craftingSlots.forEach(integer -> {
            inventory.setItem(integer, null);
            actionMap.put(integer, event -> updateInventory((Player) event.getWhoClicked()));
        });

        // Set the result slot
        emptyResultItem = plugin.getItemUtil().getItemStackFromConfig("empty-result");
        resultSlot = workbenchConfig.getInt("result-slot");
        inventory.setItem(resultSlot, emptyResultItem);
        actionMap.put(resultSlot, event -> {
            event.setCancelled(true);

            Inventory inventory = event.getInventory();

            ItemStack result = inventory.getItem(resultSlot);
            if (result == null || result.getType() == Material.AIR || result.equals(emptyResultItem))
                return;

            Player player = (Player) event.getWhoClicked();

            updateInventory(player, true, event.isShiftClick());
        });
    }


    private void updateInventory(Player player) {
        updateInventory(player, false, false);
    }

    private void updateInventory(Player player, boolean craftItem, boolean isShiftClick) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            Inventory inventory = inventoryMap.get(player.getUniqueId());
            if (inventory == null)
                return;

            EntityPlayer entityPlayer = ((CraftPlayer) player).getHandle();
            World world = entityPlayer.getWorld();

            // Create simulated inventory crafting
            InventoryCrafting invCrafting = new InventoryCrafting(
                    ((CraftInventoryView) player.getOpenInventory()).getHandle(),
                    3, 3
            );
            invCrafting.resultInventory = new InventoryCraftResult();

            // Simulate input
            int c = 0;
            for (int integer : craftingSlots) {
                ItemStack itemStack = inventory.getItem(integer);
                if (itemStack != null)
                    invCrafting.setItem(c, (CraftItemStack.asNMSCopy(itemStack)));
                c++;
            }

            // Update inventory with leftovers (i.e. cake recipe, non-matching item amounts, etc.)
            if (craftItem) {
                net.minecraft.server.v1_8_R3.ItemStack[] items = null;

                for (IRecipe irecipe : CraftingManager.getInstance().recipes) {
                    if (irecipe.a(invCrafting, world)) {
                        invCrafting.currentRecipe = irecipe;
                        items = irecipe.b(invCrafting);
                        break;
                    }
                }

                if (items == null) {
                    items = new net.minecraft.server.v1_8_R3.ItemStack[invCrafting.getSize()];

                    for (int i = 0; i < items.length; ++i)
                        items[i] = invCrafting.getItem(i);
                }

                CraftInventoryCrafting cic = new CraftInventoryCrafting(invCrafting, invCrafting.resultInventory);
                CraftItemEvent event = new CraftItemEvent(invCrafting.currentRecipe == null
                        ? new ShapedRecipe(inventory.getItem(resultSlot))
                        : invCrafting.currentRecipe.toBukkitRecipe(),
                        new CraftInventoryView(entityPlayer.getBukkitEntity(), cic, entityPlayer.activeContainer),
                        InventoryType.SlotType.RESULT,
                        resultSlot,
                        isShiftClick ? ClickType.SHIFT_LEFT : ClickType.LEFT,
                        InventoryAction.PICKUP_ALL);
                plugin.getServer().getPluginManager().callEvent(event);
                ItemStack result = event.isCancelled() ? event.getInventory().getResult() : null;

                if (!event.isCancelled()) {

                    int smallestAmount = 64;
                    for (int i = 0; i < items.length; i++) {
                        ItemStack currentItem = inventory.getItem(craftingSlots.get(i));
                        if (currentItem == null)
                            continue;

                        smallestAmount = Math.min(smallestAmount, currentItem.getAmount());
                    }

                    for (int i = 0; i < items.length; i++) {
                        net.minecraft.server.v1_8_R3.ItemStack item = items[i];

                        int craftingI = craftingSlots.get(i);
                        if (item != null) {
                            invCrafting.setItem(i, item);
                            inventory.setItem(craftingI, CraftItemStack.asBukkitCopy(item));
                            continue;
                        }

                        ItemStack previousItem = inventory.getItem(craftingI);
                        if (previousItem == null) {
                            invCrafting.setItem(i, null);
                            inventory.setItem(craftingI, null);
                            continue;
                        }

                        if (isShiftClick)
                            previousItem.setAmount(previousItem.getAmount() - smallestAmount);
                        else
                            previousItem.setAmount(previousItem.getAmount() - 1);

                        invCrafting.setItem(i, CraftItemStack.asNMSCopy(previousItem));
                        inventory.setItem(craftingI, previousItem);
                    }

                    result = inventory.getItem(resultSlot).clone();

                    if (isShiftClick) {
                        int resultAmount = result.getAmount() * smallestAmount;
                        if (resultAmount > result.getMaxStackSize()) {
                            while (resultAmount > result.getMaxStackSize()) {
                                resultAmount -= result.getMaxStackSize();
                                ItemStack clone = result.clone();
                                clone.setAmount(result.getMaxStackSize());
                                plugin.getItemUtil().give(player, clone);
                            }

                            if (resultAmount == 0) {
                                inventory.setItem(resultSlot, emptyResultItem);
                                return;
                            }

                            result.setAmount(resultAmount);
                        } else
                            result.setAmount(result.getAmount() * smallestAmount);
                    }
                } else {
                    ItemStack[] matrix = event.getInventory().getMatrix();
                    for (int i = 0; i < 9; i++) {
                        inventory.setItem(craftingSlots.get(i), matrix[i]);
                        invCrafting.setItem(i, CraftItemStack.asNMSCopy(matrix[i]));
                    }
                }

                inventory.setItem(resultSlot, emptyResultItem);
                plugin.getItemUtil().give(player, result);
            }

            net.minecraft.server.v1_8_R3.ItemStack result = CraftingManager.getInstance().craft(invCrafting, world);
            if (result == null)
                result = CraftEventFactory.callPreCraftEvent(invCrafting, null, player.getOpenInventory(), false);

            // If craft result exists, show and return;
            if (result != null) {
                inventory.setItem(resultSlot, CraftItemStack.asBukkitCopy(result));
                validationSlots.forEach(integer -> inventory.setItem(integer, validCraftItem));
            } else {
                inventory.setItem(resultSlot, emptyResultItem);
                validationSlots.forEach(integer -> inventory.setItem(integer, invalidCraftItem));
            }
        }, 1L);
    }

    @Override
    public void onClick(InventoryClickEvent event) {
        if (event.getClickedInventory() == null)
            return;

        if (event.getClickedInventory().equals(event.getView().getBottomInventory())) {
            if (event.getAction() == InventoryAction.COLLECT_TO_CURSOR)
                event.setCancelled(true);
            else
                updateInventory((Player) event.getWhoClicked());
            return;
        }

        Consumer<InventoryClickEvent> slotAction = actionMap.get(event.getRawSlot());
        if (slotAction == null)
            return;

        slotAction.accept(event);
    }

    @Override
    public void onDrag(InventoryDragEvent event) {
        boolean update = false;
        for (Integer integer : event.getNewItems().keySet()) {
            if (integer < inventory.getSize() && !craftingSlots.contains(integer)) {
                event.setCancelled(true);
                return;
            } else
                update = true;
        }

        if (update)
            updateInventory((Player) event.getWhoClicked());
    }

    @Override
    public void onClose(InventoryCloseEvent event) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->  {
            Player player = (Player) event.getPlayer();
            Inventory inventory = inventoryMap.get(player.getUniqueId());
            if (inventory == null)
                return;

            craftingSlots.forEach(slot -> {
                ItemStack returnItem = inventory.getItem(slot);
                if (returnItem == null)
                    return;

                plugin.getItemUtil().give(player, returnItem);
            });

            inventoryMap.remove(player.getUniqueId());
        }, 1L);
    }

    @Override
    public Inventory getInventory() {
        Inventory inventoryCopy = plugin.getServer().createInventory(this, inventory.getSize(), inventory.getTitle());
        for (int i = 0; i < inventory.getSize(); i++)
            inventoryCopy.setItem(i, inventory.getItem(i));
        return inventoryCopy;
    }

    public void openInventoryForPlayer(Player player) {
        Inventory inventory = getInventory();
        inventoryMap.put(player.getUniqueId(), inventory);
        player.openInventory(inventory);
    }
}

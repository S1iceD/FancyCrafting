package me.gadse.fancycrafting.util;

import me.gadse.fancycrafting.FancyCrafting;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.Map;

public enum Messages {

    PREFIX,
    PLUGIN_RELOAD,
    COMMAND_USAGE,
    RECIPE_DOES_NOT_EXIST;

    private String message = ChatColor.RED + "ERROR LOADING MESSSAGE FOR " + name() + ".";

    public void reloadMessage(FancyCrafting plugin) {
        message = color(plugin.getConfig().getString("messages." + name().toLowerCase()));
    }

    public void send(CommandSender sender) {
        send(sender, true);
    }

    @SafeVarargs
    public final void send(CommandSender sender, boolean usePrefix, Map.Entry<String, String>... placeholders) {
        String tempMessage = message;

        for (Map.Entry<String, String> placeholder : placeholders)
            tempMessage = tempMessage.replaceAll(placeholder.getKey(), placeholder.getValue());

        sender.sendMessage((usePrefix ? PREFIX.message : "") + tempMessage);
    }

    public static String color(String text) {
        if (text == null || text.isEmpty())
            return "";

        return ChatColor.translateAlternateColorCodes('&', text);
    }
}

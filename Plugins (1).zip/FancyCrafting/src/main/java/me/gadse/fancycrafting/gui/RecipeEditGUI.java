package me.gadse.fancycrafting.gui;

import me.gadse.fancycrafting.FancyCrafting;
import me.gadse.fancycrafting.util.Messages;
import me.gadse.fancycrafting.util.DataRecipe;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.function.Consumer;

public class RecipeEditGUI implements IGUI {

    private final FancyCrafting plugin;
    private final Inventory inventory;
    private final Map<Integer, Consumer<InventoryClickEvent>> actionMap = new HashMap<>();
    private final List<Integer> craftingSlots = new ArrayList<>();
    private final Map<UUID, DataRecipe> editors = new HashMap<>();
    private final int resultSlot, editNameSlot, permissionSlot;
    private final ItemStack usePermissionItem, doNotUsePermissionItem;

    public RecipeEditGUI(FancyCrafting plugin) {
        this.plugin = plugin;
        ConfigurationSection editConfig = plugin.getConfig().getConfigurationSection("recipe_edit");
        if (editConfig == null)
            throw new IllegalArgumentException("There is no recipe_edit in the config. Consider deleting it.");

        // Create the inventory
        inventory = plugin.getServer().createInventory(this,
                editConfig.getInt("size", 54),
                Messages.color(editConfig.getString("title"))
        );

        // Fill the inventory with the fill item
        ItemStack fill = plugin.getItemUtil().getItemStackFromConfig("fill");
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, fill);
            actionMap.put(i, null);
        }

        // Cache items
        ItemStack saveItem = plugin.getItemUtil().getItemStackFromConfig("save");
        ItemStack cancelItem = plugin.getItemUtil().getItemStackFromConfig("cancel");
        ItemStack editNameItem = plugin.getItemUtil().getItemStackFromConfig("edit-name");
        doNotUsePermissionItem = plugin.getItemUtil().getItemStackFromConfig("do-not-use-permission");
        usePermissionItem = plugin.getItemUtil().getItemStackFromConfig("use-permission");

        // Cache slots
        craftingSlots.addAll(editConfig.getIntegerList("crafting-slots"));
        resultSlot = editConfig.getInt("result-slot");
        editNameSlot = editConfig.getInt("edit-name-slot");
        permissionSlot = editConfig.getInt("permission-slot");
        int saveSlot = editConfig.getInt("save-slot");
        int cancelSlot = editConfig.getInt("cancel-slot");

        // Set items
        craftingSlots.forEach(integer -> {
            inventory.setItem(integer, null);
            actionMap.remove(integer);
        });
        inventory.setItem(saveSlot, saveItem);
        inventory.setItem(cancelSlot, cancelItem);
        inventory.setItem(editNameSlot, editNameItem);
        inventory.setItem(resultSlot, null);
        inventory.setItem(permissionSlot, doNotUsePermissionItem);

        // Set actions
        actionMap.remove(resultSlot);
        actionMap.put(cancelSlot, event -> new RecipeListGUI(plugin, (Player) event.getWhoClicked()));
        actionMap.put(permissionSlot, event -> {
            if (event.getCurrentItem() == null)
                return;

            if (event.getCurrentItem().equals(doNotUsePermissionItem))
                event.getInventory().setItem(permissionSlot, usePermissionItem);
            else
                event.getInventory().setItem(permissionSlot, doNotUsePermissionItem);
        });
        actionMap.put(editNameSlot, event -> {
            Inventory inventory = event.getInventory();
            new AnvilGUI.Builder()
                    .text("Name")
                    .item(new ItemStack(Material.PAPER))
                    .plugin(plugin)
                    .onComplete((player, text) -> {
                        if (plugin.getFileStorage().getRecipeByName(text) != null)
                            return AnvilGUI.Response.text("Name exists already!");

                        ItemStack nameItem = editNameItem.clone();
                        ItemMeta itemMeta = nameItem.getItemMeta();
                        List<String> lore = itemMeta.hasLore() ? itemMeta.getLore() : new ArrayList<>();
                        lore.add(text);
                        itemMeta.setLore(lore);
                        nameItem.setItemMeta(itemMeta);
                        inventory.setItem(editNameSlot, nameItem);
                        return AnvilGUI.Response.close();
                    })
                    .onClose(player -> plugin.getServer().getScheduler()
                            .runTaskLater(plugin, () -> player.openInventory(inventory), 1L))
                    .open((Player) event.getWhoClicked());
        });
        actionMap.put(saveSlot, event -> {
            Inventory inventory = event.getInventory();

            HumanEntity player = event.getWhoClicked();
            if (editors.containsKey(player.getUniqueId()))
                plugin.getFileStorage().removeRecipe(editors.get(player.getUniqueId()));

            boolean hasInput = false;
            for (Integer craftingSlot : craftingSlots) {
                ItemStack temp = inventory.getItem(craftingSlot);
                if (temp != null && temp.getType() != Material.AIR) {
                    hasInput = true;
                    break;
                }
            }

            ItemStack result = inventory.getItem(resultSlot);
            if (!hasInput || (result == null || result.getType() == Material.AIR)) {
                if (editors.containsKey(player.getUniqueId())) {
                    editors.remove(player.getUniqueId());
                    new RecipeListGUI(plugin, (Player) player);
                }
                return;
            }
            editors.remove(player.getUniqueId());

            ItemMeta originalMeta = editNameItem.getItemMeta();
            ItemMeta newMeta = inventory.getItem(editNameSlot).getItemMeta();
            DataRecipe recipe = new DataRecipe(result,
                    newMeta.getLore().size() > originalMeta.getLore().size()
                            ? newMeta.getLore().get(originalMeta.getLore().size())
                            : "",
                    inventory.getItem(permissionSlot).equals(usePermissionItem));
            for (int i = 0; i < 9; i++)
                recipe.setIngredient(i, inventory.getItem(craftingSlots.get(i)));

            plugin.getFileStorage().addRecipe(recipe);

            new RecipeListGUI(plugin, (Player) player);
        });
    }

    @Override
    public void onClick(InventoryClickEvent event) {
        if (event.getClickedInventory() == null)
            return;

        if (event.getClickedInventory().equals(event.getView().getBottomInventory())) {
            if (event.isShiftClick() || event.getAction() == InventoryAction.COLLECT_TO_CURSOR)
                event.setCancelled(true);
            return;
        }
        if (!actionMap.containsKey(event.getRawSlot()))
            return;
        event.setCancelled(true);

        Consumer<InventoryClickEvent> action = actionMap.get(event.getRawSlot());
        if (action != null)
            action.accept(event);
    }

    @Override
    public void onDrag(InventoryDragEvent event) {
        for (Integer integer : event.getNewItems().keySet()) {
            if (integer < inventory.getSize() && !craftingSlots.contains(integer) && integer != resultSlot) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @Override
    public void onClose(InventoryCloseEvent event) {
    }

    @Override
    public Inventory getInventory() {
        Inventory inventoryCopy = plugin.getServer().createInventory(this, inventory.getSize(), inventory.getTitle());
        for (int i = 0; i < inventory.getSize(); i++)
            inventoryCopy.setItem(i, inventory.getItem(i));
        return inventoryCopy;
    }

    public Inventory getInventory(Player player, DataRecipe recipe) {
        editors.put(player.getUniqueId(), recipe);

        Inventory inventoryCopy = plugin.getServer().createInventory(this, inventory.getSize(), inventory.getTitle());
        for (int i = 0; i < inventory.getSize(); i++)
            inventoryCopy.setItem(i, inventory.getItem(i));

        recipe.getIngredients().forEach((slot, itemStack) -> inventoryCopy.setItem(craftingSlots.get(slot), itemStack));
        inventoryCopy.setItem(resultSlot, recipe.getOutput());

        ItemStack nameItem = inventoryCopy.getItem(editNameSlot).clone();
        ItemMeta itemMeta = nameItem.getItemMeta();
        List<String> lore = itemMeta.hasLore() ? itemMeta.getLore() : new ArrayList<>();
        lore.add(recipe.getName());
        itemMeta.setLore(lore);
        nameItem.setItemMeta(itemMeta);
        inventoryCopy.setItem(editNameSlot, nameItem);

        if (recipe.isUsePermission())
            inventoryCopy.setItem(permissionSlot, usePermissionItem);

        return inventoryCopy;
    }
}

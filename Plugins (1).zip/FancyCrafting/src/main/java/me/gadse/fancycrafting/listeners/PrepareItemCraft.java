package me.gadse.fancycrafting.listeners;

import me.gadse.fancycrafting.FancyCrafting;
import me.gadse.fancycrafting.util.DataRecipe;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareItemCraftEvent;

public class PrepareItemCraft implements Listener {

    private final FancyCrafting plugin;

    public PrepareItemCraft(FancyCrafting plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPrepareItemCraft(PrepareItemCraftEvent event) {
        for (DataRecipe recipe : plugin.getFileStorage().getRecipes()) {
            if (recipe.fits(event.getViewers().get(0), event.getInventory().getMatrix())) {
                event.getInventory().setResult(recipe.getOutput().clone());
                break;
            }
        }
    }
}

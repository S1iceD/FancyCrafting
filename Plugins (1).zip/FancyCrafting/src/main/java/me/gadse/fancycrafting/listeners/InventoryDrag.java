package me.gadse.fancycrafting.listeners;

import me.gadse.fancycrafting.gui.IGUI;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryDragEvent;

public class InventoryDrag implements Listener {
    @EventHandler
    public void onInventoryClose(InventoryDragEvent event) {
        if (!(event.getInventory().getHolder() instanceof IGUI))
            return;

        IGUI igui = (IGUI) event.getInventory().getHolder();
        igui.onDrag(event);
    }
}

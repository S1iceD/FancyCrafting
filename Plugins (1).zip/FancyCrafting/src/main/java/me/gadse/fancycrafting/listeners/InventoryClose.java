package me.gadse.fancycrafting.listeners;

import me.gadse.fancycrafting.gui.IGUI;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;

public class InventoryClose implements Listener {
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof IGUI))
            return;

        IGUI igui = (IGUI) event.getInventory().getHolder();
        igui.onClose(event);
    }
}

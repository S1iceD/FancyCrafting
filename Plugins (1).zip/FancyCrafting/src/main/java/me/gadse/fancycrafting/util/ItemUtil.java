package me.gadse.fancycrafting.util;

import me.gadse.fancycrafting.FancyCrafting;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ItemUtil {

    private final FancyCrafting plugin;

    public ItemUtil(FancyCrafting plugin) {
        this.plugin = plugin;
    }

    public void give(Player player, ItemStack itemStack) {
        player.getInventory().addItem(itemStack)
                .forEach((slot, item) -> player.getWorld().dropItem(player.getLocation(), item));
    }

    public ItemStack getItemStackFromConfig(String path) {
        return getItemStackFromConfigRaw("items." + path);
    }

    public ItemStack getItemStackFromConfigRaw(String path) {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection(path);
        if (section == null) {
            throw new IllegalArgumentException("Path '" + path + "' does not exist.");
        } else {
            String materialString = section.getString("material");
            if (materialString == null || materialString.isEmpty()) {
                plugin.getLogger().warning(path + ".material was empty or did not exist. Falling back to dirt.");
                materialString = "dirt";
            }

            Material material = Material.getMaterial(materialString.toUpperCase());
            if (material == null) {
                plugin.getLogger().warning(materialString + " is not a valid material. Falling back to dirt.");
                material = Material.DIRT;
            }

            ItemStack item = new ItemStack(material, section.getInt("amount", 1), (short) section.getInt("data", 0));
            ItemMeta meta = item.getItemMeta();

            if (meta == null) {
                plugin.getLogger().warning("Meta of '" + path + "' does not exist.");
                return item;
            }

            String displayName;
            if ((displayName = section.getString("displayName")) != null && !displayName.isEmpty()) {
                meta.setDisplayName(Messages.color(section.getString("displayName")));
            }

            List<String> lore = new ArrayList<>();
            section.getStringList("lore").forEach((line) ->lore.add(Messages.color(line)));
            meta.setLore(lore);

            ConfigurationSection enchants = section.getConfigurationSection("enchants");
            if (enchants != null) {
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                enchants.getKeys(false).forEach((key) -> {
                    Enchantment enchantment = Enchantment.getByName(key);
                    if (enchantment == null) {
                        plugin.getLogger().warning("The enchantment for the key '" + key + "' was invalid. Skipping it.");
                    } else {
                        meta.addEnchant(enchantment, enchants.getInt(key), true);
                    }
                });
            }

            item.setItemMeta(meta);
            return item.clone();
        }
    }
}

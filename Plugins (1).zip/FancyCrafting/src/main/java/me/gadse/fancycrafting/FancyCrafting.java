package me.gadse.fancycrafting;

import me.gadse.fancycrafting.commands.FancyCraftingCommand;
import me.gadse.fancycrafting.commands.WorkbenchCommand;
import me.gadse.fancycrafting.gui.IGUI;
import me.gadse.fancycrafting.gui.RecipeEditGUI;
import me.gadse.fancycrafting.gui.RecipePreviewGUI;
import me.gadse.fancycrafting.gui.WorkbenchGUI;
import me.gadse.fancycrafting.listeners.*;
import me.gadse.fancycrafting.util.FileStorage;
import me.gadse.fancycrafting.util.ItemUtil;
import me.gadse.fancycrafting.util.Messages;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class FancyCrafting extends JavaPlugin {

    private FileStorage fileStorage;

    private ItemUtil itemUtil;

    private WorkbenchGUI workbenchGUI;
    private RecipeEditGUI recipeEditGUI;
    private RecipePreviewGUI recipePreviewGUI;

    @Override
    public void onEnable() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs())
            throw new IllegalStateException("Data folder inaccessible.");
        saveDefaultConfig();

        fileStorage = new FileStorage(this);
        itemUtil = new ItemUtil(this);

        PluginManager pluginManager = getServer().getPluginManager();
        pluginManager.registerEvents(new CraftItem(this), this);
        pluginManager.registerEvents(new InventoryClick(), this);
        pluginManager.registerEvents(new InventoryClose(), this);
        pluginManager.registerEvents(new InventoryDrag(), this);
        pluginManager.registerEvents(new PlayerInteract(this), this);
        pluginManager.registerEvents(new PrepareItemCraft(this), this);

        PluginCommand fancyCrafting = getCommand("fancycrafting");
        if (fancyCrafting != null)
            fancyCrafting.setExecutor(new FancyCraftingCommand(this));

        PluginCommand workbench = getCommand("workbench");
        if (workbench != null)
            workbench.setExecutor(new WorkbenchCommand(this));

        reload();
    }

    public void reload() {
        getServer().getOnlinePlayers().forEach(player -> {
            if (player.getOpenInventory().getTopInventory().getHolder() instanceof IGUI)
                player.closeInventory();
        });

        for (Messages message : Messages.values())
            message.reloadMessage(this);

        workbenchGUI = new WorkbenchGUI(this);
        recipeEditGUI = new RecipeEditGUI(this);
        recipePreviewGUI = new RecipePreviewGUI(this);
    }

    @Override
    public void onDisable() {
        getServer().getOnlinePlayers().forEach(player -> {
            if (player.getOpenInventory().getTopInventory().getHolder() instanceof IGUI)
                player.closeInventory();
        });
    }

    public FileStorage getFileStorage() {
        return fileStorage;
    }

    public ItemUtil getItemUtil() {
        return itemUtil;
    }

    public WorkbenchGUI getWorkbenchGUI() {
        return workbenchGUI;
    }

    public RecipeEditGUI getRecipeEditGUI() {
        return recipeEditGUI;
    }

    public RecipePreviewGUI getRecipePreviewGUI() {
        return recipePreviewGUI;
    }
}

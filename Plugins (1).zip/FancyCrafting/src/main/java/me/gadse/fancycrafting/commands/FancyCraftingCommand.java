package me.gadse.fancycrafting.commands;

import me.gadse.fancycrafting.FancyCrafting;
import me.gadse.fancycrafting.gui.RecipeListGUI;
import me.gadse.fancycrafting.util.DataRecipe;
import me.gadse.fancycrafting.util.Messages;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.AbstractMap;

public class FancyCraftingCommand implements CommandExecutor {

    private final FancyCrafting plugin;

    public FancyCraftingCommand(FancyCrafting plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String arg = args.length == 0 ? "help" : args[0].toLowerCase();

        if (!sender.hasPermission("fancycrafting." + arg))
            arg = "help";

        switch (arg) {
            case "reload": {
                plugin.reload();
                Messages.PLUGIN_RELOAD.send(sender);
                break;
            }
            case "preview": {
                if (!(sender instanceof Player))
                    break;

                if (args.length < 2) {
                    Messages.COMMAND_USAGE.send(sender, false,
                            new AbstractMap.SimpleEntry<>("%command%", "/" + label + " preview <name>"),
                            new AbstractMap.SimpleEntry<>("%usage%", "Preview a recipe by name.")
                    );
                    break;
                }

                DataRecipe recipe = plugin.getFileStorage().getRecipeByName(args[1]);
                if (recipe == null) {
                    Messages.RECIPE_DOES_NOT_EXIST.send(sender, true,
                            new AbstractMap.SimpleEntry<>("%recipe_name%", args[1])
                    );
                    break;
                }

                Player player = (Player) sender;
                player.openInventory(plugin.getRecipePreviewGUI().getInventory(player, recipe));
                break;
            }
            case "recipes": {
                if (!(sender instanceof Player))
                    break;
                Player player = (Player) sender;

                new RecipeListGUI(plugin, player);
                break;
            }
            case "vanilla": {
                if (!(sender instanceof Player))
                    break;
                Player player = (Player) sender;
                player.openWorkbench(player.getLocation(), true);
                break;
            }
            default: {
                sender.sendMessage(ChatColor.GRAY + plugin.getDescription().getName()
                        + " v" + plugin.getDescription().getVersion()
                        + " (C) " + String.join(", ", plugin.getDescription().getAuthors()));

                if (sender.hasPermission("fancycrafting.reload"))
                    Messages.COMMAND_USAGE.send(sender, false,
                            new AbstractMap.SimpleEntry<>("%command%", "/" + label + " reload"),
                            new AbstractMap.SimpleEntry<>("%usage%", "Reload messages and GUIs.")
                    );

                if (sender.hasPermission("fancycrafting.preview"))
                    Messages.COMMAND_USAGE.send(sender, false,
                            new AbstractMap.SimpleEntry<>("%command%", "/" + label + " preview <name>"),
                            new AbstractMap.SimpleEntry<>("%usage%", "Preview a recipe by name.")
                    );

                if (sender.hasPermission("fancycrafting.recipes"))
                    Messages.COMMAND_USAGE.send(sender, false,
                            new AbstractMap.SimpleEntry<>("%command%", "/" + label + " recipes"),
                            new AbstractMap.SimpleEntry<>("%usage%", "View all non-vanilla recipes.")
                    );

                if (sender.hasPermission("fancycrafting.vanilla"))
                    Messages.COMMAND_USAGE.send(sender, false,
                            new AbstractMap.SimpleEntry<>("%command%", "/" + label + " vanilla"),
                            new AbstractMap.SimpleEntry<>("%usage%", "Open the vanilla workbench.")
                    );

                if (sender.hasPermission("fancycrafting.workbench"))
                    Messages.COMMAND_USAGE.send(sender, false,
                            new AbstractMap.SimpleEntry<>("%command%", "/workbench"),
                            new AbstractMap.SimpleEntry<>("%usage%", "Open a fancy workbench.")
                    );
                break;
            }
        }

        return true;
    }
}
